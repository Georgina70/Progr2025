﻿namespace ArchivoPeliculas
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtbusquedadas = new TextBox();
            lblBusquedas = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(255, 128, 0);
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Blue;
            label1.ImageAlign = ContentAlignment.TopCenter;
            label1.Location = new Point(555, 9);
            label1.Name = "label1";
            label1.Size = new Size(163, 34);
            label1.TabIndex = 0;
            label1.Text = "Base de Datos";
            // 
            // txtbusquedadas
            // 
            txtbusquedadas.Cursor = Cursors.IBeam;
            txtbusquedadas.Location = new Point(539, 410);
            txtbusquedadas.Name = "txtbusquedadas";
            txtbusquedadas.Size = new Size(220, 23);
            txtbusquedadas.TabIndex = 2;
            // 
            // lblBusquedas
            // 
            lblBusquedas.AutoSize = true;
            lblBusquedas.BackColor = Color.FromArgb(255, 255, 192);
            lblBusquedas.BorderStyle = BorderStyle.Fixed3D;
            lblBusquedas.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblBusquedas.ForeColor = Color.FromArgb(255, 128, 128);
            lblBusquedas.Location = new Point(391, 410);
            lblBusquedas.Name = "lblBusquedas";
            lblBusquedas.Size = new Size(105, 27);
            lblBusquedas.TabIndex = 1;
            lblBusquedas.Text = "Busquedas";
            // 
            // Form7
            // 
            ClientSize = new Size(1370, 461);
            Controls.Add(txtbusquedadas);
            Controls.Add(lblBusquedas);
            Controls.Add(label1);
            Name = "Form7";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Base de Datos";
            Load += Form7_Load;
            ResumeLayout(false);
            PerformLayout();
            // 
            // Form7
            // 

        }

        #endregion

        private Label label1;
        private TextBox txtbusquedadas;
        private Label lblBusquedas;
    }
}