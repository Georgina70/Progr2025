﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ArchivoPeliculas;
using MySql.Data.MySqlClient;

namespace ArchivoPeliculas
{

    public partial class Form5 : Form
    {
        private DataGridView grid;

        public Form5()
        {
            InitializeComponent();
            CrearDataGridViews7();
            CargarDatosEnGrids7();
        }

        private void Form5_Load(object sender, EventArgs e) // 👈 nombre correcto del evento
        {


        }


        private void CrearDataGridViews7()
        {
            grid = new DataGridView
            {
                Dock = DockStyle.None,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Width = 1300,
                Height = 420,
                Location = new Point(10, 10)

            };

            var panel = new Panel
            {
                BorderStyle = BorderStyle.FixedSingle,
                Size = new Size(1500, 150),
                Location = new Point(20, 40),
                Dock = DockStyle.None
            };

            panel.Controls.Add(grid);
            this.Controls.Add(panel);
        }


        private void CargarDatosEnGrids7()
        {
            string connectionString = "server=localhost;user=root;password=;database=archivo_peliculas;";

            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM estado_de_conservacion;";
                    using (var adapter = new MySqlDataAdapter(query, conn))
                    {
                        var dt = new DataTable();
                        adapter.Fill(dt);
                        grid.DataSource = dt; // ✅ Muestra los datos en el DataGrid visible
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar la tabla 'estado de conservacion':\n{ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btncerrar_estado_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Tabla estado de conservación cerrada correctamente.", "Información",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btninforme_Click(object sender, EventArgs e)
        {

        }

        private void btninforme_Click_1(object sender, EventArgs e)
        {
            Informe informe = new Informe();
            informe.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void btn_Tablas_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();


            form7.Show();
        }
    }
}
