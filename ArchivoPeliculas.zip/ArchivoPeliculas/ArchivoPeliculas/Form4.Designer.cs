﻿namespace ArchivoPeliculas
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            btnCerrarInsp = new Button();
            groupBox1 = new GroupBox();
            cmbIncComp = new ComboBox();
            txtfabricante = new TextBox();
            txtfechafab = new TextBox();
            txtformato = new TextBox();
            txtsonido = new TextBox();
            txtmaterial = new TextBox();
            txtemulsion = new TextBox();
            txtsoporte = new TextBox();
            txtpaso = new TextBox();
            txtrollos = new TextBox();
            txttitulo = new TextBox();
            txtcategoria = new TextBox();
            txtCodigoId = new TextBox();
            txtNingreso = new TextBox();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btnguardarIT = new Button();
            btnmodificarIT = new Button();
            btneliminaIT = new Button();
            groupBox2 = new GroupBox();
            btniraestado = new Button();
            btningreso = new Button();
            btn_Tablas = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // btnCerrarInsp
            // 
            btnCerrarInsp.Location = new Point(1040, 233);
            btnCerrarInsp.Name = "btnCerrarInsp";
            btnCerrarInsp.Size = new Size(170, 33);
            btnCerrarInsp.TabIndex = 0;
            btnCerrarInsp.Text = "Cerrar Inspeccion";
            btnCerrarInsp.UseVisualStyleBackColor = true;
            btnCerrarInsp.Click += btnCerrarInsp_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(cmbIncComp);
            groupBox1.Controls.Add(txtfabricante);
            groupBox1.Controls.Add(txtfechafab);
            groupBox1.Controls.Add(txtformato);
            groupBox1.Controls.Add(txtsonido);
            groupBox1.Controls.Add(txtmaterial);
            groupBox1.Controls.Add(txtemulsion);
            groupBox1.Controls.Add(txtsoporte);
            groupBox1.Controls.Add(txtpaso);
            groupBox1.Controls.Add(txtrollos);
            groupBox1.Controls.Add(txttitulo);
            groupBox1.Controls.Add(txtcategoria);
            groupBox1.Controls.Add(txtCodigoId);
            groupBox1.Controls.Add(txtNingreso);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(254, 225);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(776, 188);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Carga de datos";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // cmbIncComp
            // 
            cmbIncComp.FormattingEnabled = true;
            cmbIncComp.Items.AddRange(new object[] { "Completa", "Incompleta" });
            cmbIncComp.Location = new Point(97, 118);
            cmbIncComp.Name = "cmbIncComp";
            cmbIncComp.Size = new Size(121, 23);
            cmbIncComp.TabIndex = 29;
            cmbIncComp.SelectedIndexChanged += cmbIncComp_SelectedIndexChanged;
            // 
            // txtfabricante
            // 
            txtfabricante.Location = new Point(593, 118);
            txtfabricante.Name = "txtfabricante";
            txtfabricante.Size = new Size(111, 23);
            txtfabricante.TabIndex = 26;
            // 
            // txtfechafab
            // 
            txtfechafab.Location = new Point(593, 81);
            txtfechafab.Name = "txtfechafab";
            txtfechafab.Size = new Size(111, 23);
            txtfechafab.TabIndex = 25;
            txtfechafab.TextChanged += txtfechafab_TextChanged;
            // 
            // txtformato
            // 
            txtformato.Location = new Point(593, 48);
            txtformato.Name = "txtformato";
            txtformato.Size = new Size(111, 23);
            txtformato.TabIndex = 24;
            // 
            // txtsonido
            // 
            txtsonido.Location = new Point(593, 15);
            txtsonido.Name = "txtsonido";
            txtsonido.Size = new Size(111, 23);
            txtsonido.TabIndex = 23;
            // 
            // txtmaterial
            // 
            txtmaterial.Location = new Point(342, 152);
            txtmaterial.Name = "txtmaterial";
            txtmaterial.Size = new Size(111, 23);
            txtmaterial.TabIndex = 22;
            // 
            // txtemulsion
            // 
            txtemulsion.Location = new Point(342, 113);
            txtemulsion.Name = "txtemulsion";
            txtemulsion.Size = new Size(111, 23);
            txtemulsion.TabIndex = 21;
            // 
            // txtsoporte
            // 
            txtsoporte.Location = new Point(342, 84);
            txtsoporte.Name = "txtsoporte";
            txtsoporte.Size = new Size(111, 23);
            txtsoporte.TabIndex = 20;
            // 
            // txtpaso
            // 
            txtpaso.Location = new Point(342, 55);
            txtpaso.Name = "txtpaso";
            txtpaso.Size = new Size(111, 23);
            txtpaso.TabIndex = 19;
            // 
            // txtrollos
            // 
            txtrollos.Location = new Point(342, 19);
            txtrollos.Name = "txtrollos";
            txtrollos.Size = new Size(111, 23);
            txtrollos.TabIndex = 18;
            // 
            // txttitulo
            // 
            txttitulo.Location = new Point(97, 152);
            txttitulo.Name = "txttitulo";
            txttitulo.Size = new Size(111, 23);
            txttitulo.TabIndex = 17;
            // 
            // txtcategoria
            // 
            txtcategoria.Location = new Point(97, 80);
            txtcategoria.Name = "txtcategoria";
            txtcategoria.Size = new Size(111, 23);
            txtcategoria.TabIndex = 15;
            // 
            // txtCodigoId
            // 
            txtCodigoId.Location = new Point(97, 51);
            txtCodigoId.Name = "txtCodigoId";
            txtCodigoId.Size = new Size(111, 23);
            txtCodigoId.TabIndex = 14;
            txtCodigoId.KeyPress += txtCodigoId_KeyPress;
            // 
            // txtNingreso
            // 
            txtNingreso.Cursor = Cursors.IBeam;
            txtNingreso.Location = new Point(97, 23);
            txtNingreso.Name = "txtNingreso";
            txtNingreso.Size = new Size(111, 23);
            txtNingreso.TabIndex = 13;
            txtNingreso.TextChanged += textBox1_TextChanged;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(513, 126);
            label14.Name = "label14";
            label14.Size = new Size(62, 15);
            label14.TabIndex = 3;
            label14.Text = "Fabricante";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(471, 92);
            label13.Name = "label13";
            label13.Size = new Size(116, 15);
            label13.TabIndex = 12;
            label13.Text = "Fecha de fabricacion";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(527, 55);
            label12.Name = "label12";
            label12.Size = new Size(52, 15);
            label12.TabIndex = 11;
            label12.Text = "Formato";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(535, 22);
            label11.Name = "label11";
            label11.Size = new Size(44, 15);
            label11.TabIndex = 10;
            label11.Text = "Sonido";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(243, 160);
            label10.Name = "label10";
            label10.Size = new Size(93, 15);
            label10.TabIndex = 9;
            label10.Text = "Tipo de Material";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(275, 121);
            label9.Name = "label9";
            label9.Size = new Size(56, 15);
            label9.TabIndex = 8;
            label9.Text = "Emulsión";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(283, 92);
            label8.Name = "label8";
            label8.Size = new Size(48, 15);
            label8.TabIndex = 7;
            label8.Text = "Soporte";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(299, 58);
            label7.Name = "label7";
            label7.Size = new Size(32, 15);
            label7.TabIndex = 6;
            label7.Text = "Paso";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(292, 26);
            label6.Name = "label6";
            label6.Size = new Size(39, 15);
            label6.TabIndex = 5;
            label6.Text = "Rollos";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(13, 160);
            label5.Name = "label5";
            label5.Size = new Size(38, 15);
            label5.TabIndex = 4;
            label5.Text = "Titulo";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(13, 121);
            label4.Name = "label4";
            label4.Size = new Size(61, 15);
            label4.TabIndex = 3;
            label4.Text = "Comp/Inc";
            label4.Click += label4_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 81);
            label3.Name = "label3";
            label3.Size = new Size(58, 15);
            label3.TabIndex = 2;
            label3.Text = "Categoria";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 54);
            label2.Name = "label2";
            label2.Size = new Size(60, 15);
            label2.TabIndex = 1;
            label2.Text = "Codigo ID";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(13, 24);
            label1.Name = "label1";
            label1.Size = new Size(79, 15);
            label1.TabIndex = 0;
            label1.Text = "N° de ingreso";
            // 
            // btnguardarIT
            // 
            btnguardarIT.BackColor = Color.YellowGreen;
            btnguardarIT.Cursor = Cursors.SizeNS;
            btnguardarIT.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnguardarIT.ForeColor = Color.Black;
            btnguardarIT.Image = (Image)resources.GetObject("btnguardarIT.Image");
            btnguardarIT.ImageAlign = ContentAlignment.MiddleLeft;
            btnguardarIT.Location = new Point(334, 420);
            btnguardarIT.Name = "btnguardarIT";
            btnguardarIT.RightToLeft = RightToLeft.Yes;
            btnguardarIT.Size = new Size(111, 40);
            btnguardarIT.TabIndex = 2;
            btnguardarIT.Text = "Guardar";
            btnguardarIT.TextAlign = ContentAlignment.MiddleRight;
            btnguardarIT.UseMnemonic = false;
            btnguardarIT.UseVisualStyleBackColor = false;
            btnguardarIT.Click += btnguardarIT_Click;
            // 
            // btnmodificarIT
            // 
            btnmodificarIT.BackColor = Color.FromArgb(255, 128, 0);
            btnmodificarIT.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnmodificarIT.Location = new Point(596, 419);
            btnmodificarIT.Name = "btnmodificarIT";
            btnmodificarIT.Size = new Size(111, 41);
            btnmodificarIT.TabIndex = 3;
            btnmodificarIT.Text = "Modificar";
            btnmodificarIT.UseVisualStyleBackColor = false;
            btnmodificarIT.Click += btnmodificarIT_Click;
            // 
            // btneliminaIT
            // 
            btneliminaIT.BackColor = Color.Red;
            btneliminaIT.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btneliminaIT.Location = new Point(857, 419);
            btneliminaIT.Name = "btneliminaIT";
            btneliminaIT.Size = new Size(117, 41);
            btneliminaIT.TabIndex = 4;
            btneliminaIT.Text = "Eliminar";
            btneliminaIT.UseVisualStyleBackColor = false;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.FromArgb(224, 224, 224);
            groupBox2.Controls.Add(btniraestado);
            groupBox2.Controls.Add(btningreso);
            groupBox2.Controls.Add(btn_Tablas);
            groupBox2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(1040, 273);
            groupBox2.Margin = new Padding(3, 4, 3, 4);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 4, 3, 4);
            groupBox2.Size = new Size(209, 184);
            groupBox2.TabIndex = 12;
            groupBox2.TabStop = false;
            groupBox2.Text = "Carga de datos";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // btniraestado
            // 
            btniraestado.BackColor = Color.FromArgb(255, 192, 128);
            btniraestado.Location = new Point(32, 72);
            btniraestado.Margin = new Padding(3, 4, 3, 4);
            btniraestado.Name = "btniraestado";
            btniraestado.Size = new Size(171, 31);
            btniraestado.TabIndex = 4;
            btniraestado.Text = "Ir a Estado de consevación";
            btniraestado.UseVisualStyleBackColor = false;
            btniraestado.Click += btniraestado_Click;
            // 
            // btningreso
            // 
            btningreso.BackColor = Color.DarkKhaki;
            btningreso.BackgroundImageLayout = ImageLayout.Center;
            btningreso.Location = new Point(32, 24);
            btningreso.Margin = new Padding(3, 4, 3, 4);
            btningreso.Name = "btningreso";
            btningreso.Size = new Size(116, 31);
            btningreso.TabIndex = 2;
            btningreso.Text = "Ir a Ingreso";
            btningreso.UseVisualStyleBackColor = false;
            btningreso.Click += btningreso_Click;
            // 
            // btn_Tablas
            // 
            btn_Tablas.Location = new Point(22, 126);
            btn_Tablas.Margin = new Padding(3, 4, 3, 4);
            btn_Tablas.Name = "btn_Tablas";
            btn_Tablas.Size = new Size(181, 31);
            btn_Tablas.TabIndex = 1;
            btn_Tablas.Text = "Ir a Tablas";
            btn_Tablas.UseVisualStyleBackColor = true;
            btn_Tablas.Click += btn_Tablas_Click;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1364, 471);
            Controls.Add(groupBox2);
            Controls.Add(btneliminaIT);
            Controls.Add(btnmodificarIT);
            Controls.Add(btnguardarIT);
            Controls.Add(groupBox1);
            Controls.Add(btnCerrarInsp);
            Name = "Form4";
            Text = "Inspeccion Técnica";
            Load += Form4_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Button btnCerrarInsp;
        private GroupBox groupBox1;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txttitulo;
        private TextBox txtcategoria;
        private TextBox txtCodigoId;
        private TextBox txtNingreso;
        private TextBox txtfabricante;
        private TextBox txtfechafab;
        private TextBox txtformato;
        private TextBox txtsonido;
        private TextBox txtmaterial;
        private TextBox txtemulsion;
        private TextBox txtsoporte;
        private TextBox txtpaso;
        private TextBox txtrollos;
        private Button btnguardarIT;
        private Button btnmodificarIT;
        private Button btneliminaIT;
        
        private ComboBox cmbIncComp;
        private GroupBox groupBox2;
        private Button btniraestado;
        private Button btningreso;
        private Button btn_Tablas;
    }
}