﻿namespace ArchivoPeliculas
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnceraringreso = new Button();
            groupBox1 = new GroupBox();
            btnlimpiarTexto = new Button();
            txtidingreso = new TextBox();
            label5 = new Label();
            btnmodificar = new Button();
            btnborrar = new Button();
            txtprocedencia = new TextBox();
            txtfechaingreso = new TextBox();
            btnguardar = new Button();
            txttitulo = new TextBox();
            txtcodigo = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            groupBox2 = new GroupBox();
            button1 = new Button();
            btnirInsp = new Button();
            btniraestado = new Button();
            btn_Tablas = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // btnceraringreso
            // 
            btnceraringreso.Location = new Point(240, 480);
            btnceraringreso.Name = "btnceraringreso";
            btnceraringreso.Size = new Size(330, 33);
            btnceraringreso.TabIndex = 0;
            btnceraringreso.Text = "Cerrar Ingreso";
            btnceraringreso.UseVisualStyleBackColor = true;
            btnceraringreso.Click += btnceraringreso_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnlimpiarTexto);
            groupBox1.Controls.Add(txtidingreso);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(btnmodificar);
            groupBox1.Controls.Add(btnborrar);
            groupBox1.Controls.Add(txtprocedencia);
            groupBox1.Controls.Add(txtfechaingreso);
            groupBox1.Controls.Add(btnguardar);
            groupBox1.Controls.Add(txttitulo);
            groupBox1.Controls.Add(txtcodigo);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(11, 222);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(758, 177);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Carga de datos";
            // 
            // btnlimpiarTexto
            // 
            btnlimpiarTexto.Location = new Point(431, 126);
            btnlimpiarTexto.Name = "btnlimpiarTexto";
            btnlimpiarTexto.Size = new Size(154, 36);
            btnlimpiarTexto.TabIndex = 11;
            btnlimpiarTexto.Text = "Limpiar Text Box";
            btnlimpiarTexto.UseVisualStyleBackColor = true;
            btnlimpiarTexto.Click += btnlimpiarTexto_Click;
            // 
            // txtidingreso
            // 
            txtidingreso.Location = new Point(180, 21);
            txtidingreso.Name = "txtidingreso";
            txtidingreso.Size = new Size(55, 23);
            txtidingreso.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(47, 32);
            label5.Name = "label5";
            label5.Size = new Size(60, 15);
            label5.TabIndex = 9;
            label5.Text = "ID Ingreso";
            // 
            // btnmodificar
            // 
            btnmodificar.Location = new Point(431, 57);
            btnmodificar.Name = "btnmodificar";
            btnmodificar.Size = new Size(154, 27);
            btnmodificar.TabIndex = 5;
            btnmodificar.Text = "Modificar Registro";
            btnmodificar.UseVisualStyleBackColor = true;
            btnmodificar.Click += btnmodificar_Click;
            // 
            // btnborrar
            // 
            btnborrar.Location = new Point(431, 90);
            btnborrar.Name = "btnborrar";
            btnborrar.Size = new Size(154, 30);
            btnborrar.TabIndex = 7;
            btnborrar.Text = "Eliminar registro";
            btnborrar.UseVisualStyleBackColor = true;
            btnborrar.Click += btnborrar_Click;
            // 
            // txtprocedencia
            // 
            txtprocedencia.Location = new Point(179, 140);
            txtprocedencia.Name = "txtprocedencia";
            txtprocedencia.Size = new Size(215, 23);
            txtprocedencia.TabIndex = 7;
            // 
            // txtfechaingreso
            // 
            txtfechaingreso.Location = new Point(179, 111);
            txtfechaingreso.Name = "txtfechaingreso";
            txtfechaingreso.Size = new Size(215, 23);
            txtfechaingreso.TabIndex = 6;
            // 
            // btnguardar
            // 
            btnguardar.Location = new Point(431, 20);
            btnguardar.Name = "btnguardar";
            btnguardar.Size = new Size(154, 31);
            btnguardar.TabIndex = 3;
            btnguardar.Text = "Agregar Nuevo Registro";
            btnguardar.UseVisualStyleBackColor = true;
            btnguardar.Click += btnguardar_Click;
            // 
            // txttitulo
            // 
            txttitulo.Location = new Point(179, 82);
            txttitulo.Name = "txttitulo";
            txttitulo.Size = new Size(215, 23);
            txttitulo.TabIndex = 5;
            // 
            // txtcodigo
            // 
            txtcodigo.Location = new Point(178, 49);
            txtcodigo.Name = "txtcodigo";
            txtcodigo.Size = new Size(215, 23);
            txtcodigo.TabIndex = 4;
            txtcodigo.TextChanged += txtcodigo_TextChanged;
            txtcodigo.KeyPress += txtcodigo_KeyPress;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(47, 148);
            label4.Name = "label4";
            label4.Size = new Size(72, 15);
            label4.TabIndex = 3;
            label4.Text = "Procedencia";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(47, 112);
            label3.Name = "label3";
            label3.Size = new Size(96, 15);
            label3.TabIndex = 2;
            label3.Text = "Fecha de Ingreso";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(47, 90);
            label2.Name = "label2";
            label2.Size = new Size(38, 15);
            label2.TabIndex = 1;
            label2.Text = "Titulo";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(47, 57);
            label1.Name = "label1";
            label1.Size = new Size(76, 15);
            label1.TabIndex = 0;
            label1.Text = "Codigo de ID";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(31, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(741, 201);
            dataGridView1.TabIndex = 2;
            dataGridView1.CellContentClick += dataGridView2_CellContentClick;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.FromArgb(224, 224, 224);
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(btnirInsp);
            groupBox2.Controls.Add(btniraestado);
            groupBox2.Controls.Add(btn_Tablas);
            groupBox2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(154, 406);
            groupBox2.Margin = new Padding(3, 4, 3, 4);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 4, 3, 4);
            groupBox2.Size = new Size(569, 67);
            groupBox2.TabIndex = 11;
            groupBox2.TabStop = false;
            groupBox2.Text = "Carga de datos";
            // 
            // button1
            // 
            button1.Location = new Point(392, 23);
            button1.Name = "button1";
            button1.Size = new Size(161, 31);
            button1.TabIndex = 7;
            button1.Text = "Ir a Base de Datos";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnirInsp
            // 
            btnirInsp.BackColor = Color.FromArgb(192, 192, 0);
            btnirInsp.Location = new Point(6, 24);
            btnirInsp.Margin = new Padding(3, 4, 3, 4);
            btnirInsp.Name = "btnirInsp";
            btnirInsp.Size = new Size(145, 31);
            btnirInsp.TabIndex = 6;
            btnirInsp.Text = "Ir a Inspección Técnica";
            btnirInsp.UseVisualStyleBackColor = false;
            btnirInsp.Click += btnirInsp_Click;
            // 
            // btniraestado
            // 
            btniraestado.BackColor = Color.FromArgb(255, 192, 128);
            btniraestado.Location = new Point(186, 24);
            btniraestado.Margin = new Padding(3, 4, 3, 4);
            btniraestado.Name = "btniraestado";
            btniraestado.Size = new Size(171, 31);
            btniraestado.TabIndex = 4;
            btniraestado.Text = "Ir a Estado de consevación";
            btniraestado.UseVisualStyleBackColor = false;
            btniraestado.Click += btniraestado_Click;
            // 
            // btn_Tablas
            // 
            btn_Tablas.Location = new Point(6, 206);
            btn_Tablas.Margin = new Padding(3, 4, 3, 4);
            btn_Tablas.Name = "btn_Tablas";
            btn_Tablas.Size = new Size(181, 31);
            btn_Tablas.TabIndex = 1;
            btn_Tablas.Text = "Ir a Tablas";
            btn_Tablas.UseVisualStyleBackColor = true;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(818, 540);
            Controls.Add(groupBox2);
            Controls.Add(dataGridView1);
            Controls.Add(btnceraringreso);
            Controls.Add(groupBox1);
            Name = "Form3";
            Text = "Ingreso de películas";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Button btnceraringreso;
        private GroupBox groupBox1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtprocedencia;
        private TextBox txttitulo;
        private TextBox txtcodigo;
        private Button btnguardar;
        private Button btnmodificar;
        private Button btnborrar;
        private DataGridView dataGridView1;
        private Label label5;
        private TextBox txtidingreso;
        private GroupBox groupBox2;
        private Button btnirInsp;
        private Button btniraestado;
        private Button btn_Tablas;
        private Button button1;
        private Button btnlimpiarTexto;
        private TextBox txtfechaingreso;
    }
}