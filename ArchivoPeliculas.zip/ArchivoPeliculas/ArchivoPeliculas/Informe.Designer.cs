﻿namespace ArchivoPeliculas
{
    partial class Informe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            cmbInformes = new ComboBox();
            btnseleccionar = new Button();
            btnguardarinforme = new Button();
            textBox1 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(37, 43);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(417, 478);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // cmbInformes
            // 
            cmbInformes.FormattingEnabled = true;
            cmbInformes.Location = new Point(631, 43);
            cmbInformes.Name = "cmbInformes";
            cmbInformes.Size = new Size(180, 23);
            cmbInformes.TabIndex = 1;
            cmbInformes.SelectedIndexChanged += cmbInformes_SelectedIndexChanged;
            // 
            // btnseleccionar
            // 
            btnseleccionar.Location = new Point(631, 152);
            btnseleccionar.Name = "btnseleccionar";
            btnseleccionar.Size = new Size(180, 23);
            btnseleccionar.TabIndex = 2;
            btnseleccionar.Text = "Seleccionar Informe";
            btnseleccionar.UseVisualStyleBackColor = true;
            btnseleccionar.Click += btnseleccionar_Click;
            // 
            // btnguardarinforme
            // 
            btnguardarinforme.Location = new Point(631, 244);
            btnguardarinforme.Name = "btnguardarinforme";
            btnguardarinforme.Size = new Size(180, 23);
            btnguardarinforme.TabIndex = 3;
            btnguardarinforme.Text = " Guardar Informe";
            btnguardarinforme.UseVisualStyleBackColor = true;
            btnguardarinforme.Click += btnguardarinforme_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(130, 12);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(224, 23);
            textBox1.TabIndex = 4;
            // 
            // Informe
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(892, 533);
            Controls.Add(textBox1);
            Controls.Add(btnguardarinforme);
            Controls.Add(btnseleccionar);
            Controls.Add(cmbInformes);
            Controls.Add(pictureBox1);
            Name = "Informe";
            Text = "Informe";
            Load += Informe_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private ComboBox cmbInformes;
        private Button btnseleccionar;
        private Button btnguardarinforme;
        private TextBox textBox1;
    }
}