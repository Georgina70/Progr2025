﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;



namespace ArchivoPeliculas
{

    public partial class Form7 : Form
    {
        private DataGridView grid;

        public Form7()
        {
            InitializeComponent();
            CrearDataGridViews8();
            CargarDatosEnGrids8();
        }



        private void CrearDataGridViews8()
        {
            grid = new DataGridView
            {
                Dock = DockStyle.None,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Width = 1300,
                Height = 320,
                Location = new Point(10, 10)
                


            };

            var panel = new Panel
            {
                BorderStyle = BorderStyle.FixedSingle,
                Size = new Size(1320, 350),
                Location = new Point(20, 40),
                Dock = DockStyle.None
            };

            panel.Controls.Add(grid);
            this.Controls.Add(panel);
        }

        private void CargarDatosEnGrids8()
        {
            string connectionString = "server=localhost;user=root;password=;database=Archivo_Peliculas;";

            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT*FROM ingreso inner join inspeccion_tecnica  on ingreso.Codigo_ID = inspeccion_tecnica.Codigo_ID";
                    using (var adapter = new MySqlDataAdapter(query, conn))
                    {
                        var dt = new DataTable();
                        adapter.Fill(dt);
                        grid.DataSource = dt; // ✅ Muestra los datos en el DataGrid visible
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar la tabla 'estado de conservacion':\n{ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}