﻿

using System;
using System.Data;
using System.Windows.Forms;
using ArchivoPeliculas;
using MySql.Data.MySqlClient;


namespace ArchivoPeliculas
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
            CrearTreeViewBasico();
        }



        private void btn_Tablas_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.Show();
        }


        private void CrearTreeViewBasico()
        {
            TreeView treeView = new TreeView();
            treeView.Dock = DockStyle.Fill;

            // Nodo raíz
            TreeNode raiz = new TreeNode("Proyectos");

            // Hijos
            TreeNode proyecto1 = new TreeNode("Busquedas Archivo Peliculas");
            TreeNode Ingreso = new TreeNode("Ingreso");
            TreeNode InspeccionTecnica = new TreeNode("Inspeccion Tecnica");
            TreeNode Estado = new TreeNode("Estado de conservacion");
            TreeNode BD = new TreeNode("Base de datos");
            TreeNode Inf = new TreeNode("Informe");

            // Asignar Tag con el tipo de formulario a abrir
            Ingreso.Tag = typeof(Form3);
            InspeccionTecnica.Tag = typeof(Form4);
            Estado.Tag = typeof(Form5);
            BD.Tag = typeof(Form7);
            Inf.Tag = typeof(Informe);


            proyecto1.Nodes.Add(Ingreso);
            proyecto1.Nodes.Add(InspeccionTecnica);
            proyecto1.Nodes.Add(Estado);
            proyecto1.Nodes.Add(BD);
            proyecto1 .Nodes.Add(Inf);


            raiz.Nodes.Add(proyecto1);

            treeView.Nodes.Add(raiz);
            treeView.ExpandAll();

            treeView.NodeMouseClick += TreeView_NodeMouseClick;

            this.Controls.Add(treeView);
        }

        private void TreeView_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {

            if (e.Node.Tag is Type formType && typeof(Form).IsAssignableFrom(formType))
            {
                Form formulario = (Form)Activator.CreateInstance(formType);
                formulario.ShowDialog(); // o formulario.ShowDialog() si quieres modal
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();


            form3.Show();

        }



        private void button3_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();


            form4.Show();
        }

        private void btniraestado_Click_1(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();


            form5.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
    

       


   
