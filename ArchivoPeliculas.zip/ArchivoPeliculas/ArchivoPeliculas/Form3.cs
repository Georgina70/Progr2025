﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Data.Common;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using System.Globalization;
using Mysqlx.Cursor;
using Mysqlx.Crud;
using System.Collections;


namespace ArchivoPeliculas
{
    public partial class Form3 : Form
    {
        private readonly string connectionString = "server=localhost;user=root;password=;database=archivo_peliculas;";
        private DataTable? dataTable;

        public Form3()
        {
            InitializeComponent();
            InitializeDataGridView();
            LoadDataFromDatabase();
            
        }

        private void InitializeDataGridView()
        {
            dataGridView1.AllowUserToAddRows = true;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ReadOnly = false;

            dataGridView1.CellEndEdit += OnCellEndEdit;
            dataGridView1.CellDoubleClick += OnCellDoubleClick;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font(dataGridView1.Font, FontStyle.Bold);
           // dataGridView1.Columns["NombreColumna"].DefaultCellStyle.Font = new Font(dataGridView1.Font, FontStyle.Bold);

            dataGridView1.DataBindingComplete += (s, e) =>
             {
                 if (dataGridView1.Columns.Count > 0)
                 {
                     dataGridView1.Columns[0].DefaultCellStyle.Font = new Font(dataGridView1.Font, FontStyle.Bold);
                     dataGridView1.Columns[0].Width = 150;
                     dataGridView1.Columns[1].Width = 150;
                     dataGridView1.Columns[2].Width = 150;
                     dataGridView1.Columns[3].Width = 150;
                     dataGridView1.Columns[4].Width = 170;


                 }
             };


            // Cuando el usuario selecciona una fila, mostrar los datos en los TextBox
dataGridView1.CellClick += (s, e) => MostrarDatosSeleccionados();
          dataGridView1.SelectionChanged += (s, e) => MostrarDatosSeleccionados();

            Controls.Add(dataGridView1);
        }
        private void LoadDataFromDatabase()
        {
            try
            {
                //que me muestre lo que esta en la base en el datagridview
                using var conn = new MySqlConnection(connectionString);
                conn.Open();
                const string query = "SELECT N_DE_INGRESO, CODIGO_ID,TITULO,FECHA_DE_INGRESO,PROCEDENCIA FROM ingreso  ORDER BY N_DE_INGRESO ";
                using var adapter = new MySqlDataAdapter(query, conn);
                dataTable = new DataTable();//es un objeto que lleno con datos que guardo en el data grid
                adapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;

                if (dataGridView1.Columns["N_DE_INGRESO"] is DataGridViewColumn idColumn)
                {
                    idColumn.ReadOnly = true;
                    idColumn.Visible = true;
                }

                dataTable.RowChanged += DataTable_RowChanged;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar datos:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DataTable_RowChanged(object? sender, DataRowChangeEventArgs e)
        {
            if (e.Action != DataRowAction.Add) return;
            if (dataTable == null) return;

            // Evitar bucle: si ya tiene ID, no procesar
            if (e.Row["N_DE_INGRESO"] is not DBNull && e.Row["N_DE_INGRESO"] is not null) return;

            string titulo = e.Row["TITULO"]?.ToString() ?? string.Empty;
            string Codigo = e.Row["CODIGO_ID"]?.ToString() ?? string.Empty;
            string fecha = e.Row["FECHA_DE_INGRESO"]?.ToString() ?? string.Empty;
            string procedencia = e.Row["PROCEDENCIA"]?.ToString() ?? string.Empty;


            if (string.IsNullOrWhiteSpace(titulo) && string.IsNullOrWhiteSpace(Codigo) && string.IsNullOrWhiteSpace(procedencia)) //&& string.IsNullOrWhiteSpace(fecha))
                return;


            try
            {
                using var conn = new MySqlConnection(connectionString);
                conn.Open();
                using var cmd = new MySqlCommand("INSERT INTO ingreso (N_DE_INGRESO,CODIGO_ID,TITULO,FECHA DE INGRESO,PROCEDENCIA ) VALUES (@id,@CODIGO_ID, @TITULO,@FECHA_DE_INGRESO,@PROCEDENCIA )", conn);
                cmd.Parameters.AddWithValue("@CODIGO_ID", string.IsNullOrWhiteSpace(Codigo) ? (object)DBNull.Value : Codigo);
                cmd.Parameters.AddWithValue("@TITULO", string.IsNullOrWhiteSpace(titulo) ? (object)DBNull.Value : titulo);
                cmd.Parameters.AddWithValue("FECHA_DE_INGRESO", string.IsNullOrWhiteSpace(fecha) ? (object)DBNull.Value : fecha);
                cmd.Parameters.AddWithValue("@PROCEDENCIA", string.IsNullOrWhiteSpace(procedencia) ? (object)DBNull.Value : procedencia);


                cmd.ExecuteNonQuery();

                long newId = cmd.LastInsertedId;
                e.Row["N_DE_INGRESO"] = newId;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al insertar:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Row.Delete();
            }
        }

        private void OnCellEndEdit(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (dataGridView1.Rows[e.RowIndex].IsNewRow) return;

            var row = dataGridView1.Rows[e.RowIndex];
            if (row.DataBoundItem is not DataRowView drv) return;

            // Solo validar ID si la fila YA DEBERÍA tenerlo (es decir, no es nueva y no es DBNull)
            // Pero si es una fila existente y no tiene ID, entonces sí advertir.
            if (drv["N_DE_INGRESO"] is DBNull || drv["N_DE_INGRESO"] is null)
            {
                // Verificar: ¿es una fila que ya fue agregada al DataTable pero sin ID?
                // Esto solo debería pasar si hay un error grave. En la mayoría de los casos, no mostrar advertencia.
                // En su lugar, intentar guardar como NUEVA (aunque técnicamente no es IsNewRow)

                // Pero para evitar falsos positivos, mejor NO mostrar advertencia aquí.
                // El sistema de inserción (RowChanged) ya maneja el guardado.
                return;
            }

                try
                {
                    int ingreso = Convert.ToInt32(drv["N_DE_INGRESO"]);
                    string codigo = drv["CODIGO_ID"]?.ToString() ?? string.Empty;
                    string titulo = drv["TITULO"]?.ToString() ?? string.Empty;
                    string fecha = drv["FECHA_DE_INGRESO"]?.ToString() ?? string.Empty;
                    string procedencia = drv["PROCEDENCIA"]?.ToString() ?? string.Empty;

                    using var conn = new MySqlConnection(connectionString);
                    conn.Open();
                    using var cmd = new MySqlCommand("UPDATE ingreso SET titulo = @TITULO, codigo = @CODIGO_ID,fecha =@FECHA_DE_INGRESO,   WHERE N_DE_INGRESO = @id", conn);
                    cmd.Parameters.AddWithValue("@TITULO", titulo);
                    cmd.Parameters.AddWithValue("@CODIGO_ID", codigo);
                    cmd.Parameters.AddWithValue("@FECHA_DE_INGRESO", fecha);
                    cmd.Parameters.AddWithValue("@PROCEDENCIA", procedencia);

                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al actualizar:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        

        private void OnCellDoubleClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            if (dataGridView1.Rows[e.RowIndex].IsNewRow) return;

            var result = MessageBox.Show(
                "¿Desea eliminar este registro?\nEsta acción no se puede deshacer.",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (result != DialogResult.Yes) return;

            var row = dataGridView1.Rows[e.RowIndex];
            if (row.DataBoundItem is not DataRowView drv) return;

            if (drv["N_DE_INGRESO"] is DBNull || drv["N_DE_INGRESO"] is null)
            {
                MessageBox.Show("No se puede eliminar un registro sin ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                int id = Convert.ToInt32(drv["N_DE_INGRESO"]);
                using var conn = new MySqlConnection(connectionString);
                conn.Open();
                using var cmd = new MySqlCommand("DELETE FROM ingreso WHERE  N_DE_INGRESO = @ID", conn);
                cmd.Parameters.AddWithValue("N_DE_INGRESO", id);
                cmd.ExecuteNonQuery();

                dataTable?.Rows.RemoveAt(e.RowIndex);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void MostrarDatosSeleccionados()
        {

            if (dataGridView1.CurrentRow == null) return;

            txtidingreso.Text = dataGridView1.CurrentRow.Cells["N_DE_INGRESO"].Value?.ToString() ?? "";
            txtcodigo.Text = dataGridView1.CurrentRow.Cells["CODIGO_ID"].Value?.ToString() ?? "";
            txttitulo.Text = dataGridView1.CurrentRow.Cells["TITULO"].Value?.ToString() ?? "";
            txtprocedencia.Text = dataGridView1.CurrentRow.Cells["PROCEDENCIA"].Value?.ToString() ?? "";
            txtfechaingreso.Text = dataGridView1.CurrentRow.Cells["FECHA_DE_INGRESO"].Value?.ToString() ?? "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnguardar_Click(object sender, EventArgs e)
        {
            {
                // Leer valores de los TextBox
                string codigo = txtcodigo.Text.Trim();
                string titulo = txttitulo.Text.Trim();
                string procedencia = txtprocedencia.Text.Trim();
                string textoFecha = txtfechaingreso.Text.Trim();

                // Intentar convertir el texto a fecha
                DateTime fecha;
                if (!DateTime.TryParseExact(textoFecha, "yyyy-MM-dd",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out fecha))
                {
                    // Si falla, intentar con otro formato (dd/MM/yyyy)
                    if (!DateTime.TryParseExact(textoFecha, "dd/MM/yyyy",
                        CultureInfo.InvariantCulture, DateTimeStyles.None, out fecha))
                    {
                        MessageBox.Show(" Formato de fecha inválido.\nUsá 'yyyy-MM-dd' o 'dd/MM/yyyy'.",
                                        "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }


                    // Insertar en la base de datos
                    try
                    {
                        using (var conn = new MySqlConnection(connectionString))
                        {
                            conn.Open();
                            string query = @"INSERT INTO ingreso 
                        (CODIGO_ID, TITULO, FECHA_DE_INGRESO, PROCEDENCIA) 
                        VALUES (@CODIGO_ID, @TITULO, @FECHA_DE_INGRESO, @PROCEDENCIA)";

                            using (var cmd = new MySqlCommand(query, conn))
                            {
                                cmd.Parameters.AddWithValue("@CODIGO_ID", codigo);
                                cmd.Parameters.AddWithValue("@TITULO", titulo);
                                cmd.Parameters.AddWithValue("@FECHA_DE_INGRESO", fecha);
                                cmd.Parameters.AddWithValue("@PROCEDENCIA", procedencia);
                                cmd.ExecuteNonQuery();



                            }

                            MessageBox.Show(" Registro agregado correctamente.",
                                            "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Limpiar campos
                            txtcodigo.Clear();
                            txttitulo.Clear();
                            txtfechaingreso.Clear();
                            txtprocedencia.Clear();
                            LoadDataFromDatabase();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("❌ Error al guardar en la base de datos:\n" + ex.Message);
                    }
                }
            }
        }





        private void btnceraringreso_Click(object sender, EventArgs e)

        {
            this.Hide();
            MessageBox.Show("Tabla estado de conservación cerrada correctamente.", "Información",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);


        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {



        }

        private void btnirInsp_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();


            form4.Show();
        }

        private void btniraestado_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();


            form5.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();


            form7.Show();
        }

        private void btnmodificar_Click(object sender, EventArgs e)
        {

            {
                // 🟦 1️⃣ Verificar si hay una fila seleccionada
                if (dataGridView1.CurrentRow == null)
                {
                    MessageBox.Show("Debe seleccionar una fila para modificar.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 🟦 2️⃣ Verificar que la columna de ID exista y tenga valor
                if (!dataGridView1.Columns.Contains("N_DE_INGRESO"))
                {
                    MessageBox.Show("No se encontró la columna 'N_DE_INGRESO'. Verifique el nombre exacto en el DataGridView.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                var cellValue = dataGridView1.CurrentRow.Cells["N_DE_INGRESO"].Value;
                if (cellValue == null || cellValue == DBNull.Value)
                {
                    MessageBox.Show("El campo 'N° DE INGRESO' está vacío.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 🟦 3️⃣ Convertir el valor del ID a entero
                int id;
                if (!int.TryParse(cellValue.ToString(), out id))
                {
                    MessageBox.Show("El ID seleccionado no es válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 🟦 4️⃣ Leer los valores desde los TextBox
                string codigo = txtcodigo.Text.Trim();
                string titulo = txttitulo.Text.Trim();
                string procedencia = txtprocedencia.Text.Trim();

                // 🟦 5️⃣ Convertir la fecha correctamente
                // Si usás un DateTimePicker, reemplazá txtfechaingreso.Text por txtfechaingreso.Value
                DateTime fechaIngreso;
                if (!DateTime.TryParse(txtfechaingreso.Text, out fechaIngreso))
                {
                    MessageBox.Show("Formato de fecha inválido. Use formato válido (por ejemplo: 2025-11-10).", "Error de fecha", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 🟦 6️⃣ Actualizar los datos en la base de datos MySQL
                try
                {
                    using (var conn = new MySqlConnection(connectionString))
                    {
                        conn.Open();

                        string sql = @"UPDATE ingreso 
                           SET CODIGO_ID = @CODIGO_ID,
                               TITULO = @TITULO,
                               FECHA_DE_INGRESO = @FECHA_DE_INGRESO,
                               PROCEDENCIA = @PROCEDENCIA
                           WHERE N_DE_INGRESO = @ID;";

                        using (var cmd = new MySqlCommand(sql, conn))
                        {
                            // 🟦 Asignar parámetros con valores o NULL si están vacíos
                            cmd.Parameters.AddWithValue("@CODIGO_ID", string.IsNullOrEmpty(codigo) ? (object)DBNull.Value : codigo);
                            cmd.Parameters.AddWithValue("@TITULO", string.IsNullOrEmpty(titulo) ? (object)DBNull.Value : titulo);
                            cmd.Parameters.AddWithValue("@FECHA_DE_INGRESO", fechaIngreso);
                            cmd.Parameters.AddWithValue("@PROCEDENCIA", string.IsNullOrEmpty(procedencia) ? (object)DBNull.Value : procedencia);
                            cmd.Parameters.AddWithValue("@ID", id);

                            int afectados = cmd.ExecuteNonQuery();

                            if (afectados > 0)
                            {
                                LoadDataFromDatabase(); // 🔄 Recargar los datos
                                MessageBox.Show("Registro actualizado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("No se modificó ningún registro. Verifique el ID.", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al actualizar el registro:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void txtcodigo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcodigo_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void btnborrar_Click(object sender, EventArgs e)
        {
            {
                if (dataGridView1.CurrentRow == null) return;
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["N_DE_INGRESO"].Value);

                var confirmar = MessageBox.Show("¿Desea eliminar este registro?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (confirmar != DialogResult.Yes) return;

                try
                {
                    using var conn = new MySqlConnection(connectionString);
                    conn.Open();
                    const string query = "DELETE FROM ingreso WHERE N_DE_INGRESO=@id";
                    using var cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();

                    LoadDataFromDatabase();

                    MessageBox.Show("Registro eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al eliminar registro:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnlimpiarTexto_Click(object sender, EventArgs e)
        {
            // Limpiar campos
            txtidingreso.Clear();
            txtcodigo.Clear();

            txttitulo.Clear();
            txtfechaingreso.Clear();
            txtprocedencia.Clear();
           txtcodigo.Focus();

        }
    }
}

       
               

