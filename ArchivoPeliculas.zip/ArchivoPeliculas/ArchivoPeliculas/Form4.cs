﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ArchivoPeliculas
{

    public partial class Form4 : Form
    {
        private DataGridView grid;
        string connectionString = "server=localhost;user=root;password=;database=archivo_peliculas;";


        public Form4()
        {
            InitializeComponent();
            CrearDataGridViews6();
            CargarDatosEnGrids6();
        }

        private void Form4_Load(object sender, EventArgs e) 
        {


        }


        private void CrearDataGridViews6()
        {
            grid = new DataGridView
            {
                Dock = DockStyle.None,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Width = 1300,
                Height = 150,
                Location = new Point(10, 10)



            };

            var panel = new Panel
            {
                BorderStyle = BorderStyle.FixedSingle,
                Size = new Size(1320, 180),
                Location = new Point(20, 40),
                Dock = DockStyle.None
            };

            panel.Controls.Add(grid);
            this.Controls.Add(panel);
        }

        private void CargarDatosEnGrids6()
        {
            string connectionString = "server=localhost;user=root;password=;database=archivo_peliculas;";

            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM inspeccion_tecnica;";
                    using (var adapter = new MySqlDataAdapter(query, conn))
                    {
                        var dt = new DataTable();
                        adapter.Fill(dt);
                        grid.DataSource = dt; //  Muestra los datos en el DataGrid 
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar la tabla 'ingreso':\n{ex.Message}",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form4_Load_1(object sender, EventArgs e)
        {

        }

        private void btnCerrarInsp_Click(object sender, EventArgs e)
        {

            this.Hide();
            MessageBox.Show("Tabla Inspección cerrada correctamente.", "Información",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void btnguardarIT_Click(object sender, EventArgs e)
        {

            // Leer valores de los TextBox

            string ningreso = txtNingreso.Text.Trim();
            string codigo = txtCodigoId.Text.Trim();
            string titulo = txttitulo.Text.Trim();
            string comp = cmbIncComp.Text.Trim();
            string categoria = txtcategoria.Text.Trim();
            string formato = txtformato.Text.Trim();
            string sonido = txtsonido.Text.Trim();
            string material = txtmaterial.Text.Trim();
            string soporte = txtsoporte.Text.Trim();
            string paso = txtpaso.Text.Trim();
            string rollos = txtrollos.Text.Trim();
            string fabricante = txtfabricante.Text.Trim();
            string fechaf = txtfechafab.Text.Trim();
            string emulsion = txtemulsion.Text.Trim();


            // Insertar en la base de datos
            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"INSERT INTO inspeccion_tecnica 
                        (CODIGO_ID, CATEGORIA,COMP_INCOMP, TITULO,CANTIDAD_DE_ROLLOS,PASO,SOPORTE,EMULSION, TIPO_DE_MATERIAL,SONIDO,FORMATO,FECHA_DE_FABRICACION,FABRICANTE)
                        VALUES (@CODIGO_ID,@CATEGORIA,@COMP_INC, @TITULO,@CANTIDAD_DE_ROLLOS,@PASO,@SOPORTE,@EMULSION,@TIPO_DE_MATERIAL,@SONIDO,@FORMATO,@FECHA_DE_FABRICACION,@FABRICANTE)";

                    using (var cmd = new MySqlCommand(query, conn))
                    {

                        cmd.Parameters.AddWithValue("@CODIGO_ID", codigo);

                        cmd.Parameters.AddWithValue("@CATEGORIA", categoria);
                        cmd.Parameters.AddWithValue("@COMP_INCOMP", comp);
                        cmd.Parameters.AddWithValue("@TITULO", titulo);
                        cmd.Parameters.AddWithValue("@CANTIDAD_DE_ROLLOS", rollos);
                        cmd.Parameters.AddWithValue("@PASO", paso);
                        cmd.Parameters.AddWithValue("@SOPORTE", soporte);
                        cmd.Parameters.AddWithValue("@EMULSION", emulsion);
                        cmd.Parameters.AddWithValue("@TIPO_DE_MATERIAL", material);
                        cmd.Parameters.AddWithValue("@SONIDO", sonido);
                        cmd.Parameters.AddWithValue("@FORMATO", formato);
                        cmd.Parameters.AddWithValue("@FECHA_DE_FABRICACION", fechaf);
                        cmd.Parameters.AddWithValue("@FABRICANTE", fabricante);

                        cmd.ExecuteNonQuery();



                    }




                    MessageBox.Show("✅ Registro agregado correctamente.",
                                        "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Limpiar campos

                    txttitulo.Clear();
                    cmbIncComp.Items.Clear();
                    txtcategoria.Clear();
                    txtformato.Clear();
                    txtsonido.Clear();
                    txtmaterial.Clear();
                    txtsoporte.Clear();
                    txtpaso.Clear();
                    txtrollos.Clear();
                    txtfabricante.Clear();
                    txtfechafab.Clear();
                    txtemulsion.Clear();
                    CargarDatosEnGrids6();


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Error al guardar en la base de datos:\n" + ex.Message);
            }
        }

        private void txtCompInc_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbIncComp_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btningreso_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();


            form3.Show();
        }

        private void btniraestado_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();


            form5.Show();
        }

        private void btn_Tablas_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();


            form7.Show();
        }

        private void txtfechafab_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnmodificarIT_Click(object sender, EventArgs e)
        {
            string ningreso = txtNingreso.Text.Trim();
            string codigo = txtCodigoId.Text.Trim();
            string titulo = txttitulo.Text.Trim();
            string comp = cmbIncComp.Text.Trim();
            string categoria = txtcategoria.Text.Trim();
            string formato = txtformato.Text.Trim();
            string sonido = txtsonido.Text.Trim();
            string material = txtmaterial.Text.Trim();
            string soporte = txtsoporte.Text.Trim();
            string paso = txtpaso.Text.Trim();
            string rollos = txtrollos.Text.Trim();
            string fabricante = txtfabricante.Text.Trim();
            string fechaf = txtfechafab.Text.Trim();
            string emulsion = txtemulsion.Text.Trim();
        }

        private void txtCodigoId_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }
            

    }
}

        

       