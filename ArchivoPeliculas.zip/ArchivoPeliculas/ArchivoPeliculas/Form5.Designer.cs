﻿namespace ArchivoPeliculas
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btncerrar_estado = new Button();
            btninforme = new Button();
            groupBox1 = new GroupBox();
            cmbaptoproyeccion = new ComboBox();
            cmbEstado = new ComboBox();
            cmbcristalizacion = new ComboBox();
            cmbdegradacioncolor = new ComboBox();
            cmbSindrome = new ComboBox();
            txtrutainforme = new TextBox();
            txtIngresoC = new TextBox();
            txtIDC = new TextBox();
            txttituloC = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2 = new GroupBox();
            btnirInsp = new Button();
            btniraestado = new Button();
            btningreso = new Button();
            btn_Tablas = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // btncerrar_estado
            // 
            btncerrar_estado.Location = new Point(776, 319);
            btncerrar_estado.Name = "btncerrar_estado";
            btncerrar_estado.Size = new Size(92, 33);
            btncerrar_estado.TabIndex = 0;
            btncerrar_estado.Text = "Cerrar";
            btncerrar_estado.UseVisualStyleBackColor = true;
            btncerrar_estado.Click += btncerrar_estado_Click;
            // 
            // btninforme
            // 
            btninforme.Location = new Point(755, 250);
            btninforme.Name = "btninforme";
            btninforme.Size = new Size(137, 33);
            btninforme.TabIndex = 1;
            btninforme.Text = "Informe ";
            btninforme.UseVisualStyleBackColor = true;
            btninforme.Click += btninforme_Click_1;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(cmbaptoproyeccion);
            groupBox1.Controls.Add(cmbEstado);
            groupBox1.Controls.Add(cmbcristalizacion);
            groupBox1.Controls.Add(cmbdegradacioncolor);
            groupBox1.Controls.Add(cmbSindrome);
            groupBox1.Controls.Add(txtrutainforme);
            groupBox1.Controls.Add(txtIngresoC);
            groupBox1.Controls.Add(txtIDC);
            groupBox1.Controls.Add(txttituloC);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(207, 225);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(522, 285);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Carga de Datos";
            // 
            // cmbaptoproyeccion
            // 
            cmbaptoproyeccion.FormattingEnabled = true;
            cmbaptoproyeccion.Items.AddRange(new object[] { "Si", "NO" });
            cmbaptoproyeccion.Location = new Point(391, 226);
            cmbaptoproyeccion.Name = "cmbaptoproyeccion";
            cmbaptoproyeccion.Size = new Size(121, 23);
            cmbaptoproyeccion.TabIndex = 17;
            // 
            // cmbEstado
            // 
            cmbEstado.FormattingEnabled = true;
            cmbEstado.Items.AddRange(new object[] { "Excelente", "Muy Buena", "Buena", "Regular", "Mala" });
            cmbEstado.Location = new Point(79, 227);
            cmbEstado.Name = "cmbEstado";
            cmbEstado.Size = new Size(121, 23);
            cmbEstado.TabIndex = 16;
            // 
            // cmbcristalizacion
            // 
            cmbcristalizacion.FormattingEnabled = true;
            cmbcristalizacion.Items.AddRange(new object[] { "Si", "No" });
            cmbcristalizacion.Location = new Point(158, 163);
            cmbcristalizacion.Name = "cmbcristalizacion";
            cmbcristalizacion.Size = new Size(121, 23);
            cmbcristalizacion.TabIndex = 15;
            // 
            // cmbdegradacioncolor
            // 
            cmbdegradacioncolor.FormattingEnabled = true;
            cmbdegradacioncolor.Items.AddRange(new object[] { "Si", "No" });
            cmbdegradacioncolor.Location = new Point(157, 132);
            cmbdegradacioncolor.Name = "cmbdegradacioncolor";
            cmbdegradacioncolor.Size = new Size(121, 23);
            cmbdegradacioncolor.TabIndex = 14;
            // 
            // cmbSindrome
            // 
            cmbSindrome.FormattingEnabled = true;
            cmbSindrome.Items.AddRange(new object[] { "No tiene", "Iniciada", "Leve", "Avanzada" });
            cmbSindrome.Location = new Point(157, 100);
            cmbSindrome.Name = "cmbSindrome";
            cmbSindrome.Size = new Size(121, 23);
            cmbSindrome.TabIndex = 13;
            // 
            // txtrutainforme
            // 
            txtrutainforme.Location = new Point(157, 192);
            txtrutainforme.Name = "txtrutainforme";
            txtrutainforme.Size = new Size(355, 23);
            txtrutainforme.TabIndex = 12;
            // 
            // txtIngresoC
            // 
            txtIngresoC.Location = new Point(105, 25);
            txtIngresoC.Name = "txtIngresoC";
            txtIngresoC.Size = new Size(47, 23);
            txtIngresoC.TabIndex = 11;
            // 
            // txtIDC
            // 
            txtIDC.Location = new Point(241, 25);
            txtIDC.Name = "txtIDC";
            txtIDC.Size = new Size(113, 23);
            txtIDC.TabIndex = 10;
            // 
            // txttituloC
            // 
            txttituloC.Location = new Point(79, 66);
            txttituloC.Name = "txttituloC";
            txttituloC.Size = new Size(328, 23);
            txttituloC.TabIndex = 9;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(25, 235);
            label9.Name = "label9";
            label9.Size = new Size(42, 15);
            label9.TabIndex = 8;
            label9.Text = "Estado";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(25, 200);
            label8.Name = "label8";
            label8.Size = new Size(76, 15);
            label8.TabIndex = 7;
            label8.Text = "Ruta Informe";
            label8.Click += label8_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(241, 230);
            label7.Name = "label7";
            label7.Size = new Size(135, 15);
            label7.TabIndex = 6;
            label7.Text = "Apta para su proyección";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(24, 168);
            label6.Name = "label6";
            label6.Size = new Size(77, 15);
            label6.TabIndex = 5;
            label6.Text = "Cristalización";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(158, 33);
            label5.Name = "label5";
            label5.Size = new Size(62, 15);
            label5.TabIndex = 4;
            label5.Text = "Codigo_ID";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(22, 132);
            label4.Name = "label4";
            label4.Size = new Size(120, 15);
            label4.TabIndex = 3;
            label4.Text = "Degradación de color";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(22, 105);
            label3.Name = "label3";
            label3.Size = new Size(119, 15);
            label3.TabIndex = 2;
            label3.Text = "Sindrome del vinagre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 74);
            label2.Name = "label2";
            label2.Size = new Size(38, 15);
            label2.TabIndex = 1;
            label2.Text = "Titulo";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 33);
            label1.Name = "label1";
            label1.Size = new Size(79, 15);
            label1.TabIndex = 0;
            label1.Text = "N° de ingreso";
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.FromArgb(224, 224, 224);
            groupBox2.Controls.Add(btnirInsp);
            groupBox2.Controls.Add(btniraestado);
            groupBox2.Controls.Add(btningreso);
            groupBox2.Controls.Add(btn_Tablas);
            groupBox2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(935, 256);
            groupBox2.Margin = new Padding(3, 4, 3, 4);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 4, 3, 4);
            groupBox2.Size = new Size(209, 184);
            groupBox2.TabIndex = 13;
            groupBox2.TabStop = false;
            groupBox2.Text = "Carga de datos";
            // 
            // btnirInsp
            // 
            btnirInsp.BackColor = Color.FromArgb(192, 192, 0);
            btnirInsp.Location = new Point(26, 63);
            btnirInsp.Margin = new Padding(3, 4, 3, 4);
            btnirInsp.Name = "btnirInsp";
            btnirInsp.Size = new Size(145, 31);
            btnirInsp.TabIndex = 6;
            btnirInsp.Text = "Ir a Inspección Técnica";
            btnirInsp.UseVisualStyleBackColor = false;
            // 
            // btniraestado
            // 
            btniraestado.BackColor = Color.FromArgb(255, 192, 128);
            btniraestado.Location = new Point(26, 100);
            btniraestado.Margin = new Padding(3, 4, 3, 4);
            btniraestado.Name = "btniraestado";
            btniraestado.Size = new Size(171, 31);
            btniraestado.TabIndex = 4;
            btniraestado.Text = "Ir a Estado de consevación";
            btniraestado.UseVisualStyleBackColor = false;
            // 
            // btningreso
            // 
            btningreso.BackColor = Color.DarkKhaki;
            btningreso.BackgroundImageLayout = ImageLayout.Center;
            btningreso.Location = new Point(32, 24);
            btningreso.Margin = new Padding(3, 4, 3, 4);
            btningreso.Name = "btningreso";
            btningreso.Size = new Size(116, 31);
            btningreso.TabIndex = 2;
            btningreso.Text = "Ir a Ingreso";
            btningreso.UseVisualStyleBackColor = false;
            // 
            // btn_Tablas
            // 
            btn_Tablas.Location = new Point(16, 142);
            btn_Tablas.Margin = new Padding(3, 4, 3, 4);
            btn_Tablas.Name = "btn_Tablas";
            btn_Tablas.Size = new Size(181, 31);
            btn_Tablas.TabIndex = 1;
            btn_Tablas.Text = "Ir a Tablas";
            btn_Tablas.UseVisualStyleBackColor = true;
            btn_Tablas.Click += btn_Tablas_Click;
            // 
            // Form5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1370, 561);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(btninforme);
            Controls.Add(btncerrar_estado);
            Name = "Form5";
            Text = "Estado de conservación";
            Load += Form5_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Button btncerrar_estado;
        private Button btninforme;
        private GroupBox groupBox1;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label9;
        private TextBox txtIDC;
        private TextBox txttituloC;
        private ComboBox cmbEstado;
        private ComboBox cmbcristalizacion;
        private ComboBox cmbdegradacioncolor;
        private ComboBox cmbSindrome;
        private TextBox txtrutainforme;
        private TextBox txtIngresoC;
        private ComboBox cmbaptoproyeccion;
        private GroupBox groupBox2;
        private Button btnirInsp;
        private Button btniraestado;
        private Button btningreso;
        private Button btn_Tablas;
    }
}