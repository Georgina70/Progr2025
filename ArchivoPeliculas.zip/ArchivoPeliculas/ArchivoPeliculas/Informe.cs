﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ArchivoPeliculas
{
    public partial class Informe : Form
    {

        private readonly string connectionString = "server=localhost;user=root;password=;database=archivo_peliculas;";


        private string carpetaInformes = Path.Combine(Application.StartupPath, "Informes");
        public Informe()
        {
            InitializeComponent();

            // Crear la carpeta si no existe
            if (!Directory.Exists(carpetaInformes))
                Directory.CreateDirectory(carpetaInformes);

            CargarNombresImagenes();
        }

        private void CargarNombresImagenes()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM estado_de_conservacion ORDER BY N_DE_INGRESO";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    cmbInformes.DisplayMember = "TITULO_ORIGINAL";
                    cmbInformes.ValueMember = "CODIGO_ID";
                    cmbInformes.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los informes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            pictureBox1.Image?.Dispose();
            base.OnFormClosed(e);
        }



        private void cmbInformes_SelectedIndexChanged(object sender, EventArgs e)
        {


            if (cmbInformes.SelectedValue == null || cmbInformes.SelectedValue == DBNull.Value) return;

            string id = cmbInformes.SelectedValue.ToString();
            // int id = Convert.ToInt32(cmbInformes.SelectedValue);

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT informe FROM estado_de_conservacion WHERE N_DE_INGRESO = @ID";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("N_DE_INGRESO", id);
                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        string ruta = result.ToString();
                        if (File.Exists(ruta))
                        {
                            pictureBox1.Image?.Dispose(); // Liberar imagen anterior
                            pictureBox1.Image = Image.FromFile(ruta);
                        }
                        else
                        {
                            pictureBox1.Image = null;
                            MessageBox.Show("El informe no se encuentra en la ruta:\n" + ruta, "Archivo no encontrado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        pictureBox1.Image = null;
                    }
                }
            }


            catch (Exception ex)
            {



                MessageBox.Show("Error al cargar el Informe: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        

        private void btnseleccionar_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Informes|* jpeg";
                ofd.Title = "Seleccionar un Informe";

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    // Previsualizar
                    pictureBox1.Image?.Dispose();
                    pictureBox1.Image = Image.FromFile(ofd.FileName);

                    // Opcional: sugerir nombre basado en el archivo
                    textBox1.Text = Path.GetFileNameWithoutExtension(ofd.FileName);
                }
            }
        }

        private void btnguardarinforme_Click(object sender, EventArgs e)

        {

            if (pictureBox1.Image == null)
            {
                MessageBox.Show("Primero seleccione una imagen.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string nombre = textBox1.Text.Trim();
            if (string.IsNullOrEmpty(nombre))
            {
                MessageBox.Show("Ingrese un nombre para la imagen.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Obtener ruta original (del OpenFileDialog no se guarda, así que usamos la del PictureBox)
            // Pero como no guardamos la ruta original, copiaremos la imagen a nuestra carpeta
            try
            {
                // Generar nombre único para evitar colisiones
                string extension = ".jpeg"; // puedes detectar la extensión real si lo deseas
                string nombreArchivo = $"{Guid.NewGuid()}{extension}";
                string rutaGuardada = Path.Combine(carpetaInformes, nombreArchivo);

                // Guardar la imagen en la carpeta
                pictureBox1.Image.Save(rutaGuardada, System.Drawing.Imaging.ImageFormat.Jpeg);

                // Guardar en la base de datos
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO estado_de_conservacion (Informe) VALUES (@informe)";
                    MySqlCommand cmd = new MySqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@informe", rutaGuardada); // Ruta absoluta

                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Imagen guardada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Recargar lista
                CargarNombresImagenes();

                // Limpiar
                textBox1.Clear();
                pictureBox1.Image?.Dispose();
                pictureBox1.Image = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar la imagen: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Informe_Load(object sender, EventArgs e)
        {

        }
    }
}





      
